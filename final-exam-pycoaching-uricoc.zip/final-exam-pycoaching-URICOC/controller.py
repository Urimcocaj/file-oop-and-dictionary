from model import Color, FuelType, Manufacturer, Transmission, Vehicle
import csv
from typing import List

class VehicleFileManager:
    def __init__(self, file_path):
        self.file_path = file_path



    def import_vehicles_from_file(self, file_path):
        with open(file_path, newline="") as csv_file:
            csv_reader = csv.reader(csv_file)
            data = []
            for row in csv_reader:
                data.append(','.join(row))
        return data

    def rewrite_file(self, vehicle_list):
        vehicle_string_for_rewrite = ""
        for vehicle in vehicle_list:
            vehicle_string_for_rewrite = self.prepare_the_vehicle_for_rewriting(vehicle_string_for_rewrite, vehicle)
            vehicle_string_for_rewrite += "\n"
        
        try:
            with open(self.file_path, 'w', newline='') as csvfile:
                csvfile.write(vehicle_string_for_rewrite)
        except IOError:
            print("An error occurred while writing the file.")


    def prepare_the_vehicle_for_rewriting(self, vehicle_string_for_rewrite, vehicle):
        vehicle_values = [
            str(vehicle.get_id()),
            str(vehicle.get_brand().name),
            str(vehicle.get_model()),
            str(vehicle.get_horse_power()),
            str(vehicle.get_price()),
            str(vehicle.get_color().name),
            str(vehicle.get_mileage()),
            str(vehicle.get_production_year()),            
            str(vehicle.get_fuel_type().name),
            str(vehicle.get_transmission().name),
        ]
        vehicle_string_for_rewrite += ",".join(vehicle_values)
        return vehicle_string_for_rewrite

 
class VehicleShopPrinter:
    
    def print_available_vehicles(self, vehicle_list):
        header = self.prepare_vehicles_header_for_display()
        print(header)
        for vehicle in vehicle_list:
            vehicle_data = self.prepare_vehicles_string_for_display(vehicle)
            print(vehicle_data)

    def prepare_vehicles_header_for_display(self):
        header = [
            "\nVehicleShop\n\n",
            "ID:\t",
            "Manufacturer\t",
            "Model\t\t",
            "Horse-Power\t",
            "Price\t\t",
            "Color\t\t",
            "Mileage\t\t",
            "Production Year\t\t",
            "Fuel Type\t\t",
            "Transmission\n"
        ]
        return ''.join(header)

    def prepare_vehicles_string_for_display(self, vehicle):
        vehicle_string = [
            str(vehicle.get_id()) + ".",
            "\t",
            str(vehicle.get_brand().name),
            "\t\t",
            str(vehicle.get_model()),
            "\t\t",
            str(vehicle.get_horse_power()),
            "\t\t",
            str(vehicle.get_price()),
            "\t\t",
            str(vehicle.get_color().name),
            "\t\t",
            str(vehicle.get_mileage()),
            "\t\t",
            str(vehicle.get_production_year()),
            "\t\t\t",
            str(vehicle.get_fuel_type().name),
            "\t\t\t",
            str(vehicle.get_transmission().name)
        ]
        return ''.join(vehicle_string)
    
    def print_vehicle_sold_message(self, vehicle_chosen_id):
        print("\nVehicle with ID", vehicle_chosen_id, "was sold.")
    
    def print_vehicle_id_to_sell_message(self):
        print("\n\n Please enter the number (ID) of the vehicle you want to sell: ")



class VehicleShopProcessor:

    def sell_vehicle(self, vehicles_list, vehicle_chosen_id):
    # selling a vehicle means to remove it from the available vehicle list
        iterator = vehicles_list.__iter__()
        while True:
            try:
                vehicle = iterator.__next__()
                vehicle_id = vehicle.get_id()
                if vehicle_id == vehicle_chosen_id:
                    vehicles_list.remove(vehicle)
            except StopIteration:
                break


class VehicleTransformer:
    def transform_data_array_to_vehicle_objects(self, vehicle_data_array: List[str]) -> List[Vehicle]:
        vehicle_list = []
        print(vehicle_data_array)
        for vehicle_as_string in vehicle_data_array:
            vehicle = self.transform_to_vehicle_object(vehicle_as_string)
            vehicle_list.append(vehicle)
        return vehicle_list
    
    def transform_to_vehicle_object(self, vehicle_as_string: str) -> Vehicle:
        vehicle_as_array = vehicle_as_string.split(",")
        vehicle_id = int(vehicle_as_array[0])
        brand = self.get_brand_from_string(vehicle_as_array[1])
        model = vehicle_as_array[2]
        horse_power = int(vehicle_as_array[3])
        price = float(vehicle_as_array[4])
        color = self.get_color_from_string(vehicle_as_array[5])
        mileage = int(vehicle_as_array[6])
        production_year = int(vehicle_as_array[7])
        fuel_type = self.get_fuel_type_from_string(vehicle_as_array[8])
        transmission = self.get_transmission_from_string(vehicle_as_array[9])

        vehicle = Vehicle(vehicle_id, brand, model, horse_power, price, color, mileage,production_year, fuel_type, transmission )
        return vehicle

    def get_brand_from_string(self, brand_like_string: str) -> Manufacturer:
        for brand in Manufacturer:
            if brand.name == brand_like_string:
                return brand
        raise ValueError(f"Manufacturer not supported: {brand_like_string}")

    def get_color_from_string(self, color_like_string: str) -> Color:
        for color in Color:
            if color.name == color_like_string:
                return color
        raise ValueError(f"Color not supported: {color_like_string}")

    def get_fuel_type_from_string(self, fuel_type_like_string: str) -> FuelType:
        for fuel in FuelType:
            if fuel.name == fuel_type_like_string:
                return fuel
        raise ValueError(f"Fuel type not supported: {fuel_type_like_string}")

    def get_transmission_from_string(self, transmission_as_string: str) -> Transmission:
        for transmission in Transmission:
            if transmission.name == transmission_as_string:
                return transmission
        raise ValueError(f"Transmission not supported: {transmission_as_string}")

