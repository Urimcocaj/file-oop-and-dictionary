from enum import Enum

class Color(Enum):
    BLACK = 1
    WHITE = 2
    RED = 3
    YELLOW = 4
    BLUE = 5
    GREY = 6
    BROWN = 7

class FuelType(Enum):
    GASOLINE = 1
    DIESEL_FUEL = 2

class Manufacturer(Enum):
    AUDI = 1
    BMW = 2
    HONDA = 3
    SKODA = 4
    VW = 5

class Transmission(Enum):
    AUTOMATIC = 1
    MANUAL = 2

class Vehicle:
    def __init__(self, id, brand, model, horse_power, price, color, mileage, production_year, fuel_type,  transmission):
        self.__id = id
        self.__brand = brand
        self.__model = model
        self.__horse_power = horse_power
        self.__price = price
        self.__color = color
        self.__mileage = mileage
        self.__production_year = production_year
        self.__fuel_type = fuel_type
        self.__transmission = transmission
        
    
    def get_id(self):
        return self.__id
    
    def get_brand(self):
        return self.__brand
    
    def get_model(self):
        return self.__model
    
    def get_horse_power(self):
        return self.__horse_power
    
    def get_price(self):
        return self.__price
    
    def get_color(self):
        return self.__color
    
    def get_mileage(self):
        return self.__mileage
    
    def get_production_year(self):
        return self.__production_year
    
    def get_fuel_type(self):
        return self.__fuel_type
    
    def get_transmission(self):
        return self.__transmission
    
    

        ##########################
    
    def set_id(self, id):
        self.__id = id
        
    def set_brand(self, brand):
        self.__brand = brand
        
    def set_model(self, model):
        self.__model = model
        
    def set_horse_power(self, horse_power):
        self.__horse_power = horse_power
        
    def set_price(self, price):
        self.__price = price
        
    def set_color(self, color):
        self.__color = color
        
    def set_mileage(self, mileage):
        self.__mileage = mileage
        
    def set_production_year(self, production_year):
        self.__production_year = production_year

    def set_fuel_type(self, fuel_type):
        self.__fuel_type = fuel_type

        
    def set_transmission(self, transmission):
        self.__transmission = transmission




    